export class User{
    constructor(
        Fullname:string,
        Email:string,
        phoneNumber:number,
        service:string,
        Dob:Date,
        gender:string,
        password:string,
        confirmpassword:string,
        city:string,
        state:string,
        pincode:number,
        aadharno:number
    ){}


}