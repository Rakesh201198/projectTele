import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators, FormGroup } from '@angular/forms';
import { PasswordValidator } from 'src/app/shared/password.validator';
import { User } from '../user';
import { RegserviceService } from '../regservice.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  obj={Fullname:"",Email:"",phoneNumber:"",service:"",Dob:"",gender:"",password:"",confirmpassword:"",city:"",
  state:"",pincode:"",aadharno:""};
  user:User;
  message:any=[];
  registrationform:FormGroup;

  get FullName(){
    return this.registrationform.get('Fullname');
  }
  get Email(){
    return this.registrationform.get('Email');
  }

  constructor(private fb: FormBuilder,private service:RegserviceService){}
   ngOnInit() {
    this.registrationform=this.fb.group({
    id:[''],
    Fullname :['', Validators.required],
    Email:[''],
    phoneNumber:[''],
    service:[''],
    Dob:[''],
    gender:[''],
    password:[''],
    confirmpassword:[''],
    city:[''],
    state:[''],
    pincode:[''],
    aadharno:['']
  },
  {
    validator : PasswordValidator
  });
  }
  public registerNow()
  {
    if (this.registrationform.invalid) {
      console.log("invalid user")
      return;
  }
    console.log("in register method "+this.user)
    var res=this.service.registere(this.user);
    res.subscribe((data)=>this.user=data);
  }
}
