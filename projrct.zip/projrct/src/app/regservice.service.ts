import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class RegserviceService {
  private baseurl='http://localhost:9999/registers';


    constructor(private http:HttpClient){ }

    public registere(user:User):Observable<User>
    {
      return this.http.post<User>(`${this.baseurl}`, user)
    }

}
