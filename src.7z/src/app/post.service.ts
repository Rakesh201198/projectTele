import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
   
@Injectable({
  providedIn: 'root'
})
export class PostService {
  private url = 'http://localhost:8081/register';
    
  constructor(private httpClient: HttpClient) { }
   
  getPosts(){
    return this.httpClient.get(this.url);
  }
 
  //updatePost(id)
  //{
    //return this.httpClient.put(this.url+'/'+id,Response);
  //}
  deletePost(id){
    return this.httpClient.delete(this.url+'/'+id);
  }
   
}