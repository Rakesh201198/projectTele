export class User {
  id:number;
  fullname:string;
  email:string;
  phoneno:number;
  dob:Date;
  gender:string;
  service:string;
  password:string;
  confirmpassword:string;
  city:string;
  state:string;
  pincode:number;
  aadharno:string;
    constructor(){
        
    }
}
