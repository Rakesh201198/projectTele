import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import {User} from '../user';
import { UserService } from '../user.service'


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

 submitted=false; 
 user: User = new User();
 ckk=false;
 constructor(private _service : RegistrationService, private UserService: UserService,
    private router: Router) { }

  ngOnInit(): void {
  }
  loginUser(){
    this.submitted=true;
   this._service.loginUserFromRemote(this.user).subscribe(
  data =>console.log("response recived"),
  error =>console.log("exception occured")
  )
  }
  
  newUser(): void {
    this.submitted = false;
    this.user = new User();
  }

  save() {
    this.UserService
    .createUser(this.user).subscribe(data => {
      console.log(data)
      this.user = new User();
      this.gotoList();
    }, 
    error => console.log(error));
  }

  onSubmit() {
    this.submitted = true;
    this.save();    
  }

  gotoList() {
    this.router.navigate(['/userlist']);
  }
}




