import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';
import {User} from './user';
import {HttpClient} from '@angular/common/http';
import { ValidatorFn, AbstractControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  patternValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        return null;
      }
      const regex = new RegExp('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,}$');
      const valid = regex.test(control.value);
      return valid ? null : { invalidpassword: true };
    };
  }

  MatchPassword(password: string, confirmpassword: string) {
    return (formGroup: FormGroup) => {
      const passwordControl = formGroup.controls[password];
      const confirmpasswordControl = formGroup.controls[confirmpassword];

      if (!passwordControl || !confirmpasswordControl) {
        return null;
      }

      if (confirmpasswordControl.errors && !confirmpasswordControl.errors.passwordMismatch) {
        return null;
      }

      if (passwordControl.value !== confirmpasswordControl.value) {
        confirmpasswordControl.setErrors({ passwordMismatch: true });
      } else {
        confirmpasswordControl.setErrors(null);
      }
    }
  }
  constructor(private _http :HttpClient) { }
  public loginUserFromRemote(user:User):Observable<any>{
  return this._http.post<any>("http://localhost:8081/register",user)
  

}
}