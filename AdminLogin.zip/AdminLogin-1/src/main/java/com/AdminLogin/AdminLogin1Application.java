package com.AdminLogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminLogin1Application {

	public static void main(String[] args) {
		SpringApplication.run(AdminLogin1Application.class, args);
	}

}
