package com.AdminLogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminLogin1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
